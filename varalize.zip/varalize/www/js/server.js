function autoLogin() {

	var dados = {
		device : "cc34ce8b7079b535"
	};
	//PARA MOBILE DEVICES var dados = {device: device.uuid};
	//alert("carreguei");
	//http://sites.jf.ifsudestemg.edu.br/derconline/varaldoif/varalize/
	//http://localhost/varal/index.php/varalize/autoLogin

	$.ajax({
		type : "POST",
		dataType : "json",
		url : "http://sites.jf.ifsudestemg.edu.br/derconline/varaldoif/varalize/autoLogin",
		async : false,
		data : dados,
		success : function(JSON) {
			if (JSON.result == true) {
				//alert(JSON.msg);
				setTimeout("window.location=\'profile.html\'");
			} else {
				alert(JSON.msg);
			}
		}
	});
}


function profile() {

	var dados = {
		device : "cc34ce8b7079b535"
	};
	//PARA MOBILE DEVICES var dados = {device: device.uuid};
	$.ajax({
		type : "POST",
		dataType : "json",
		url : "http://sites.jf.ifsudestemg.edu.br/derconline/varaldoif/varalize/getProfile",
		async : false,
		data : dados,
		success : function(JSON) {
			if (JSON.result == true) {
				
				$("#main-page").html("<section id='affix'><div class='page-header'></div>"+
				"<h4>Olá<br/><font style='color:#2E7D32;'>"+JSON.dados.nome+"</font></h5>"+
				"<hr class='bs-docs-separator'>"+
				"<h6>Você doou "+JSON.dados.pecas+" itens e possui "+JSON.dados.moedas+" moedas</h6>"+
				"<p>"+
					"Utilize no dia do evento que acontecerá no dia <b>06 de maio de 2015, das 10h às 21h</b>."+
				"</p>"+
					"<address>"+
					"<strong>Bloco N - Salão de Eventos</strong>"+
					"<br/>"+
						"IF Sudeste MG Câmpus Juiz de Fora"+
					"<br/>"+
					"Rua Bernardo Mascarenhas, 1283, Bairro Fábrica"+
					"<br/>"+
					"<abbr>Telefone</abbr> (32) 4009-3069"+
				"</address>"+     
			"</section>");				
				
			} else {
				alert(JSON.msg);
			}
		}
	});
}

