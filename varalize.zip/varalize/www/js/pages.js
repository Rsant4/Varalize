function changePage(){
	
	
	
	url=  window.location.href;	
	query = url.split("?");
	param = query[1].split("&amp");
	
	//alert(param);
	
	
	
	if(param == 1){
		
			content = '<h4 class="green-text">Conheça</h4>'+
						'<p  class="caption justify-align">'+
							'O Varal do IF é uma rede de trocas de roupas, calçados, acessórios, livros e filmes '+
							'promovido pelo IF Sudeste MG Câmpus Juiz de Fora e aberto ao público.'+
						'</p>'+
						'<p  class="caption justify-align">'+
							'Imagine renovar seu guarda-roupa sem gastar um tostão? Foi com essa proposta que o Varal do IF surgiu. '+
							'Somos um brechó cultural onde as pessoas trocam roupas entre si. '+
							'Fazemos circular a peça de roupa/livro que não tem mais utilidade para uma pessoa,	mas que poderá servir para outra.</p>';
	}
	if(param == 2){
		 		content = '<h4 class="green-text">Regras</h4>'+
					  '<p  class="caption justify-align">'+
					  'As roupas devem estar limpas e em perfeitas condições. Os calçados sem danos, os acessórios sem defeitos, os livros sem páginas rasgadas ou faltando e os filmes sem arranhões.'+
					 '</p>';
	}
		
	if(param == 3){
			content = '<h4 class="green-text">Como Participar</h4>'+
					  '<p  class="caption justify-align">'+
						'Aceitamos roupas, calçados, acessórios, livros e filmes em bom estado de conservação e com potencial de troca.'+
					 '</p>'+
					 '<p  class="caption justify-align">'+
					  'Nossa equipe fará uma triagem dessas peças e pontuará cada uma delas. Os pontos são convertidos em moedas sociais pois, não aceitamos dinheiro por aqui.'+
					  '<br/>No dia do evento, o participante utilizará suas moedas sociais para comprar outros itens disponíveis.'+
					  '<br/>As peças que não forem selecionadas para o Varal do IF ou que não forem "compradas" serão doadas para uma instituição filantrópica.'+
					  '<br/>Curtiu a ideia? Então faça parte dessa rede!</p>';
	}
	
	
	$('#page').html(content);
	
}








