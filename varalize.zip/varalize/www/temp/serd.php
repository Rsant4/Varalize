<?php

$entities = array('Á' => '&Aacute;', 'È' => '&Egrave;', 'ô' => '&ocirc;', 'Ç' => '&Ccedil;', 'á' => '&aacute;', 'è' => '&egrave;', 'Ò' => '&Ograve;', 'ç' => '&ccedil;', 'Â' => '&Acirc;', 'Ë' => '&Euml;', 'ò' => '&ograve;', 'â' => '&acirc;', 'ë' => '&euml;', 'Ø' => '&Oslash;', 'Ñ' => '&Ntilde;', 'À' => '&Agrave;', 'Ð' => '&ETH;', 'ø' => '&oslash;', 'ñ' => '&ntilde;', 'à' => '&agrave;', 'ð' => '&eth;', 'Õ' => '&Otilde;', 'Å' => '&Aring;', 'õ' => '&otilde;', 'Ý' => '&Yacute;', 'å' => '&aring;', 'Í' => '&Iacute;', 'Ö' => '&Ouml;', 'ý' => '&yacute;', 'Ã' => '&Atilde;', 'í' => '&iacute;', 'ö' => '&ouml;', 'ã' => '&atilde;', 'Î' => '&Icirc;', '"' => '&quot;', 'Ä' => '&Auml;', 'î' => '&icirc;', 'Ú' => '&Uacute;', '<' => '&lt;', 'ä' => '&auml;', 'Ì' => '&Igrave;', 'ú' => '&uacute;', '>' => '&gt;', 'Æ' => '&AElig;', 'ì' => '&igrave;', 'Û' => '&Ucirc;', 'æ' => '&aelig;', 'Ï' => '&Iuml;', 'û' => '&ucirc;', 'ï' => '&iuml;', 'Ù' => '&Ugrave;', '®' => '&reg;', 'É' => '&Eacute;', 'ù' => '&ugrave;', '©' => '&copy;', 'é' => '&eacute;', 'Ó' => '&Oacute;', 'Ü' => '&Uuml;', 'Þ' => '&THORN;', 'Ê' => '&Ecirc;', 'ó' => '&oacute;', 'ü' => '&uuml;', 'þ' => '&thorn;', 'ê' => '&ecirc;', 'Ô' => '&Ocirc;', 'ß' => '&szlig;');


foreach ($entities as $key => $value) {		
	$set = implode($value, array_reverse(explode($key, $str)));	
	
}
